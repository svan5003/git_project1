from data import db_session
from data.users import User

db_session.global_init("db/blogs.sqlite")

# капитан
cap = User()
cap.sur_name = "Scott"
cap.name = "Ridley"
cap.age = 21
cap.position = "captain"
cap.speciality = "research engineer"
cap.address = "module_1"
cap.email = "scott_chief@mars.org"
# колонист 1
col1 = User()
col1.sur_name = "Vader"
col1.name = "Darth"
col1.age = 23
col1.position = "young captain"
col1.speciality = "dark lord"
col1.address = "module_2"
col1.email = "lucasfilmf@mars.org"
# колонист 2
col2 = User()
col2.sur_name = "Maskr"
col2.name = "Elon"
col2.age = 48
col2.position = "analytic"
col2.speciality = "genius billionaire playboy philanthropist"
col2.address = "module_3"
col2.email = "spacex@mars.org"
# колонист 3
col3 = User()
col3.sur_name = "Solomakhin"
col3.name = "Ivan"
col3.age = 17
col3.position = "expert"
col3.speciality = "all questions of the humanity"
col3.address = "module_4"
col3.email = "svan5003@mars.org"

# добавляем колонистов в бд
session = db_session.create_session()
session.add(cap)
session.add(col1)
session.add(col2)
session.add(col3)
session.commit()
