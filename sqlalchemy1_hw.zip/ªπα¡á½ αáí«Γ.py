from data import db_session
from flask import Flask, render_template, redirect
from data.jobs import Jobs

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret_key'


@app.route("/")
def table():
    db_session.global_init("db/blogs.sqlite")
    session = db_session.create_session()
    s = [[job.id, job.job, job.team_leader, job.work_size, job.collaborators, job.is_finished] for job in
         session.query(Jobs).all()]
    return render_template("web_bd.html", spis=s, title="Табличка")


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')